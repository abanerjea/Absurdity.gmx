GMMovie DLL by Nintendofreak88

You are free to use this DLL in any way you wish as long as you give 
me credit. I am in no way responsible for damages caused  by use of 
this DLL. USE AT YOUR OWN RISK!

Ok enough of that stuff so anyway thanks for downloading! This DLL is 
for using Windows MCI stuff in your game as well as adding more
functionality to it. It is mainly intended for video files although
audio files do work too. I didn't include any sample files because
then the filesize would be huge and 56k'ers would be mad. Read the help
file for more information and happy programming! :)

If you have a question, comment, or suggestion contact me at 
nintendofreak88@bis.midco.net